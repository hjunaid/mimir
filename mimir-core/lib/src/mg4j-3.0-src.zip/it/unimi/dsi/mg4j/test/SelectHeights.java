package it.unimi.dsi.mg4j.test;

import it.unimi.dsi.fastutil.io.FastBufferedOutputStream;
import it.unimi.dsi.mg4j.index.DiskBasedIndex;
import it.unimi.dsi.io.FastBufferedReader;
import it.unimi.dsi.lang.MutableString;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.martiansoftware.jsap.JSAP;
import com.martiansoftware.jsap.JSAPException;
import com.martiansoftware.jsap.JSAPResult;
import com.martiansoftware.jsap.Parameter;
import com.martiansoftware.jsap.SimpleJSAP;
import com.martiansoftware.jsap.UnflaggedOption;

/** Separates a stat file into various heights. */

final public class SelectHeights {
	
	private SelectHeights() {}

	public static void main( final String[] arg ) throws IOException, JSAPException {

		SimpleJSAP jsap = new SimpleJSAP( SelectHeights.class.getName(), "Prints or selects parts of a stat file using global counts.",
			new Parameter[] {
				new UnflaggedOption( "basename", JSAP.STRING_PARSER, JSAP.REQUIRED, "The basename of the height files." ),
				new UnflaggedOption( "h", JSAP.INTEGER_PARSER, JSAP.REQUIRED, "The maximum height to scan." )
		});

		JSAPResult jsapResult = jsap.parse( arg );
		if ( jsap.messagePrinted() ) return;
		Pattern pattern = Pattern.compile( "\t" );
		Matcher matcher = pattern.matcher( "" );
		
		final int h = jsapResult.getInt( "h" );
		final String basename = jsapResult.getString( "basename" );
		final PrintStream printStream[] = new PrintStream[ h + 1 ];
		for( int i = 0; i <= h; i++ ) printStream[ i ] = new PrintStream( new FastBufferedOutputStream( new FileOutputStream( basename + "-" + i + DiskBasedIndex.STATS_EXTENSION ) ) );
		
		final MutableString line = new MutableString();
		final FastBufferedReader reader = new FastBufferedReader( new InputStreamReader( System.in ) );
		
		int l, start;
		while( reader.readLine( line ) != null ) {
			if ( line.charAt( 0 ) == '#' ) continue;
			matcher.reset( line );
			l = 0;
			start = 0;
			while( matcher.find() && l <= h ) {
				printStream[ l ].println( line.subSequence( start, matcher.start() ) );
				start = matcher.end();
				l++;
			}
		}
		
		for( int i = 0; i <= h; i++ ) printStream[ i ].close();
	}
}

// Local Variables:
// mode: jde
// tab-width: 4
// End:
