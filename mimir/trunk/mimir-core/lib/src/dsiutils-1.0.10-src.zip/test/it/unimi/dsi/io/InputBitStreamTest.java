package test.it.unimi.dsi.io;

import it.unimi.dsi.io.InputBitStream;

import java.io.IOException;
import java.util.Arrays;

import junit.framework.TestCase;

public class InputBitStreamTest extends TestCase {

	public void testReadAligned() throws IOException {
		byte[] a = { 1 }, A = new byte[ 1 ];
		new InputBitStream( a ).read( A, 8 );
		assertTrue( Arrays.toString( a ) + " != " + Arrays.toString( A ), Arrays.equals( a, A ) );
		byte[] b = { 1, 2 }, B = new byte[ 2 ];
		new InputBitStream( b ).read( B, 16 );
		assertTrue( Arrays.toString( b ) + " != " + Arrays.toString( B ), Arrays.equals( b, B ) );
		byte[] c = { 1, 2, 3 }, C = new byte[ 3 ];
		new InputBitStream( c ).read( C, 24 );
		assertTrue( Arrays.toString( c ) + " != " + Arrays.toString( C ), Arrays.equals( c, C ) );
	}
	
	public void testOverflow() throws IOException {
		InputBitStream ibs = new InputBitStream( new byte[ 0 ] );
		ibs.readInt( 0 );
	}
}
