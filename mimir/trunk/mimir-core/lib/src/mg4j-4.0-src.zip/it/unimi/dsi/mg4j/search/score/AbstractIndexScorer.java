package it.unimi.dsi.mg4j.search.score;

/*		 
 * MG4J: Managing Gigabytes for Java
 *
 * Copyright (C) 2004-2010 Paolo Boldi and Sebastiano Vigna
 *
 *  This library is free software; you can redistribute it and/or modify it
 *  under the terms of the GNU Lesser General Public License as published by the Free
 *  Software Foundation; either version 3 of the License, or (at your option)
 *  any later version.
 *
 *  This library is distributed in the hope that it will be useful, but
 *  WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 *  or FITfNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License
 *  for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with this program; if not, see <http://www.gnu.org/licenses/>.
 *
 */

import it.unimi.dsi.mg4j.index.Index;
import it.unimi.dsi.mg4j.search.DocumentIterator;

import java.io.IOException;

/** An abstract subclass of {@link it.unimi.dsi.mg4j.search.score.AbstractScorer}.
 * It provides additionally caching of the {@linkplain #currIndex indices used by the current iterator} for
 * scorers that actually use multiple indices.
 */
public abstract class AbstractIndexScorer extends AbstractScorer {
	/** The current number of elements in {@link #currIndex}. */
	protected int n;
	/** An array containing the indices in {@link DocumentIterator#indices()} for {@link #documentIterator}; 
	 * it is set up by {@link #wrap(DocumentIterator)}. */
	protected Index currIndex[];
			
	/** Wraps the given document iterator.
	 * 
	 * <p>Besides the services provided by {@link AbstractScorer#wrap(DocumentIterator)},
	 * this method sets up {@link #currIndex} so that it refers to the indices
	 * actually used in <code>documentIterator</code>.
	 * 
	 * @param documentIterator the document iterator that will be used in subsequent calls to
	 * {@link #score()} and {@link #score(Index)}. 
	 */
	
	public void wrap( final DocumentIterator documentIterator ) throws IOException {
		super.wrap( documentIterator );
		n = documentIterator.indices().size();
		currIndex = new Index[ n ];
		int j = 0;
		for( Index i: documentIterator.indices() ) currIndex[ j++ ] = i;
	}
}
