package it.unimi.dsi.mg4j.index.payload;

/*		 
 * MG4J: Managing Gigabytes for Java
 *
 * Copyright (C) 2007 Paolo Boldi and Sebastiano Vigna 
 *
 *  This library is free software; you can redistribute it and/or modify it
 *  under the terms of the GNU Lesser General Public License as published by the Free
 *  Software Foundation; either version 2.1 of the License, or (at your option)
 *  any later version.
 *
 *  This library is distributed in the hope that it will be useful, but
 *  WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 *  or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License
 *  for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 */

import org.apache.commons.collections.Predicate;

/** An abstract payload.
 * 
 * <p>The main responsibility of this class is that of implementing {@link #rangeFilter(Payload, Payload)}
 * using the {@link Comparable} methods.
 */


public abstract class AbstractPayload implements Payload {

	protected final class ComparatorPayloadPredicate implements Predicate {
		private final Payload left;
		private final Payload right;

		protected ComparatorPayloadPredicate( final Payload left, final Payload right ) {
			this.left = left == null ? null : left.copy();
			this.right = right == null ? null : right.copy();
		}

		public boolean evaluate( final Object payload ) {
			return ( left == null || left.compareTo( (Payload)payload ) <= 0 ) && ( right == null || right.compareTo( (Payload)payload ) >= 0 ); 
		}
		
		public String toString() {
			return "[" + ( left != null ? left : "\u221e" ) + ".." + ( right != null ? right : "-\u221e" ) + "]";
		}
	}
	
	public ComparatorPayloadPredicate rangeFilter( Payload left, Payload right ) {
		return new ComparatorPayloadPredicate( left, right );
	}
}
