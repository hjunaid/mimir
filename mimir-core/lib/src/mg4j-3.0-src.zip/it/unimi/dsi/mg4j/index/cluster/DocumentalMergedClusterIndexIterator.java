package it.unimi.dsi.mg4j.index.cluster;

/*		 
 * MG4J: Managing Gigabytes for Java
 *
 * Copyright (C) 2006-2009 Sebastiano Vigna 
 *
 *  This library is free software; you can redistribute it and/or modify it
 *  under the terms of the GNU Lesser General Public License as published by the Free
 *  Software Foundation; either version 2.1 of the License, or (at your option)
 *  any later version.
 *
 *  This library is distributed in the hope that it will be useful, but
 *  WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 *  or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License
 *  for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 */
import java.io.IOException;

import it.unimi.dsi.fastutil.ints.IntIterator;
import it.unimi.dsi.mg4j.index.Index;
import it.unimi.dsi.mg4j.index.IndexIterator;
import it.unimi.dsi.mg4j.index.payload.Payload;
import it.unimi.dsi.mg4j.search.visitor.DocumentIteratorVisitor;


/** An index iterator merging iterators from local indices.
 *  
 * @author Alessandro Arrabito
 * @author Sebastiano Vigna
 */

public class DocumentalMergedClusterIndexIterator extends DocumentalMergedClusterDocumentIterator implements IndexIterator {
	/** A cached copy of the iterators, to avoid type casts. */
	protected final IndexIterator[] indexIterator;
	/** The precomputed frequency. */
	protected final int frequency;
	/** The reference index. */
	protected final DocumentalMergedCluster index;
	/** The term associated to this index iterator. */
	protected String term;
	/** The id associated to this index iterator. */
	protected int id;
	
	public DocumentalMergedClusterIndexIterator( final DocumentalClusterIndexReader indexReader, final IndexIterator[] indexIterator, final int[] usedIndex ) throws IOException {
		super( indexReader, indexIterator, usedIndex );
		this.index = (DocumentalMergedCluster)indexReader.index;
		this.indexIterator = indexIterator;
		int t = 0;
		for ( int i = indexIterator.length; i-- != 0; ) t += indexIterator[ i ].frequency();
		frequency = t;
	}

	public DocumentalMergedClusterIndexIterator term( final CharSequence term ) {
		this.term = term == null ? null : term.toString();
		return this;
	}

	public String term() { 
		return term;
	}

	public DocumentalMergedClusterIndexIterator id( final int id ) {
		this.id = id;
		return this;
	}
	
	public int id() {
		return id;
	}
	
	public Index index() {
		return index;
	}
	
	public int frequency() {
		return frequency;
	}

	public Payload payload() throws IOException {
		if ( currentIterator < 0 ) throw new IllegalStateException( "There is no current payload: nextDocument() has never been called" );
		return indexIterator[ currentIterator ].payload();
	}
	
	public int count() throws IOException {
		if ( currentIterator < 0 ) throw new IllegalStateException( "There is no current count: nextDocument() has never been called" );
		return indexIterator[ currentIterator ].count();
	}

	public IntIterator positions() throws IOException {
		if ( currentIterator < 0 ) throw new IllegalStateException( "There are no current positions: nextDocument() has never been called" );
		return indexIterator[ currentIterator ].positions();
	}

	public int positions( int[] positions ) throws IOException {
		if ( currentIterator < 0 ) throw new IllegalStateException( "There are no current positions: nextDocument() has never been called" );
		return indexIterator[ currentIterator ].positions( positions );
	}

	public int[] positionArray() throws IOException {
		if ( currentIterator < 0 ) throw new IllegalStateException( "There are no current positions: nextDocument() has never been called" );
		return indexIterator[ currentIterator ].positionArray();
	}

	public <T> T accept( final DocumentIteratorVisitor<T> visitor ) throws IOException {
		return visitor.visit( this );
	}
	
	public <T> T acceptOnTruePaths( final DocumentIteratorVisitor<T> visitor ) throws IOException {
		return visitor.visit( this );
	}
	
	public int termNumber() {
		// ALERT: to be implemented
		throw new UnsupportedOperationException( "To be implemented" );
	}

	public IndexIterator weight( final double weight ) {
		super.weight( weight );
		return this;
	}

}
