	package it.unimi.dsi.mg4j.search;

/*		 
 * MG4J: Managing Gigabytes for Java
 *
 * Copyright (C) 2003-2009 Paolo Boldi and Sebastiano Vigna 
 *
 *  This library is free software; you can redistribute it and/or modify it
 *  under the terms of the GNU Lesser General Public License as published by the Free
 *  Software Foundation; either version 2.1 of the License, or (at your option)
 *  any later version.
 *
 *  This library is distributed in the hope that it will be useful, but
 *  WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 *  or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License
 *  for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 */

import java.io.IOException;

/** An abstract document iterator helping in the implementation of {@link it.unimi.dsi.mg4j.search.ConsecutiveDocumentIterator}
 * and {@link it.unimi.dsi.mg4j.search.OrderedAndDocumentIterator}. 
 */

public abstract class AbstractOrderedIntervalDocumentIterator extends AbstractIntersectionDocumentIterator {

	public final static boolean DEBUG = false;
	public final static boolean ASSERTS = false;
	
	/** Creates a new abstract document iterator.
	 * 
	 * @param documentIterator the underlying document iterators (at least one). The must all return the same
	 * singleton set as {@link DocumentIterator#indices()}.
	 * @throws IOException 
	 */
	protected AbstractOrderedIntervalDocumentIterator( final DocumentIterator[] documentIterator ) throws IOException {
		super( documentIterator );
		if ( soleIndex == null ) throw new IllegalArgumentException();
	}

	public int nextDocument() throws IOException {
		while( super.nextDocument() != -1 && ! intervalIterator().hasNext() );
		return last;
	}
	
	public int skipTo( final int n ) throws IOException {
		// The easy case.
		if ( last >= n ) return last;
		if ( next >= n ) return nextDocument();
		// We first try to get an aligned set of iterators.
		int res = super.skipTo( n );
		// If this doesn't work, be bail out.
		if ( res == Integer.MAX_VALUE ) return Integer.MAX_VALUE;

		// Otherwise, we must manually check that there are consecutive intervals.
		if ( intervalIterator().hasNext() ) return res;
		// If not, we invalidate and check whether there is another possible document.
		return nextDocument() != -1 ? last : Integer.MAX_VALUE;
	}


	/** An abstract interval iterator helping in the implementation of 
	 * {@link ConsecutiveDocumentIterator} and {@link OrderedAndDocumentIterator}
	 * interval iterator member classes. */
	
	protected abstract class AbstractOrderedIntervalIterator extends AbstractCompositeIntervalIterator implements IntervalIterator {
		public AbstractOrderedIntervalIterator() {
			super( n );
		}

	}

	/** An abstract interval iterator helping in the implementation of 
	 * {@link ConsecutiveDocumentIterator} and {@link OrderedAndDocumentIterator}
	 * internal interval iterator member classes. The difference with {@link AbstractOrderedIntervalDocumentIterator}
	 * is that this class assumes that all document iterators are actually index iterators.
	 * The algorithms in this (very common) case can be significantly simplified, obtaining
	 * a large gain in performance. */
	
	protected abstract class AbstractOrderedIndexIntervalIterator extends AbstractCompositeIndexIntervalIterator implements IntervalIterator {

		public AbstractOrderedIndexIntervalIterator() {
			super( n );
		}
		
		public int extent() {
			return n;
		}
	}
}
