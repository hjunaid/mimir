package it.unimi.dsi.mg4j.search.score;

/*		 
 * MG4J: Managing Gigabytes for Java
 *
 * Copyright (C) 2004-2010 Paolo Boldi and Sebastiano Vigna
 *
 *  This library is free software; you can redistribute it and/or modify it
 *  under the terms of the GNU Lesser General Public License as published by the Free
 *  Software Foundation; either version 3 of the License, or (at your option)
 *  any later version.
 *
 *  This library is distributed in the hope that it will be useful, but
 *  WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 *  or FITfNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License
 *  for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with this program; if not, see <http://www.gnu.org/licenses/>.
 *
 */

import it.unimi.dsi.fastutil.Hash;
import it.unimi.dsi.fastutil.doubles.DoubleIterator;
import it.unimi.dsi.fastutil.objects.ObjectIterator;
import it.unimi.dsi.fastutil.objects.Reference2DoubleMap;
import it.unimi.dsi.fastutil.objects.Reference2DoubleOpenHashMap;
import it.unimi.dsi.mg4j.index.Index;
import it.unimi.dsi.mg4j.search.DocumentIterator;

import java.io.IOException;
import java.util.Map.Entry;

import org.apache.log4j.Logger;

/** An abstract subsclass of {@link it.unimi.dsi.mg4j.search.score.AbstractIndexScorer}
 * providing internal storage and copy of the weight map, faster array-based
 * access to the latter, and a default implementation of {@link #score()}.
 * 
 * <p><strong>Warning:</strong> implementing subclasses <strong>must</strong> implement
 * {@link it.unimi.dsi.mg4j.search.score.Scorer#copy()} so that the state of the
 * weight map is replicated, too.
 */
public abstract class AbstractWeightedScorer extends AbstractIndexScorer {
	private static final Logger LOGGER = Logger.getLogger( AbstractWeightedScorer.class );
	
	/** A map associating a weight with each index. */
	protected Reference2DoubleOpenHashMap<Index> index2Weight = new Reference2DoubleOpenHashMap<Index>( 1, Hash.VERY_FAST_LOAD_FACTOR );
	{
		// We leave it empty, but with default value 1, so all indices are peers.
		index2Weight.defaultReturnValue( 1 );
	}
	/** An array parallel to {@link #currIndex} containing the current corresponding values in {@link #index2Weight};
	 *  it is set up by {@link #wrap(DocumentIterator)}. */
	protected double currWeight[];
	
	/** Copies the argument internally, rescaling weights so they sum up to one.
	 * 
	 * @param index2Weight the new map from indices to weights.
	 * @return true.
	 */
	public synchronized boolean setWeights( final Reference2DoubleMap<Index> index2Weight ) {
		this.index2Weight.clear();
		this.index2Weight.defaultReturnValue( 0 ); // Since we're setting up values, we must assume missing indices have weight 0.
		
		double weightSum = 0;
		for( DoubleIterator i = index2Weight.values().iterator(); i.hasNext(); ) weightSum += i.nextDouble();
		if ( weightSum == 0 ) weightSum = 1; // No positive weights.
		for( ObjectIterator<Entry<Index, Double>> i = index2Weight.entrySet().iterator(); i.hasNext(); ) {
			Reference2DoubleMap.Entry<Index> e = (Reference2DoubleMap.Entry<Index>)i.next();
			this.index2Weight.put( e.getKey(), e.getDoubleValue() / weightSum );
		}

		this.index2Weight.trim();
		LOGGER.debug( "New weight map for " + this + ": " + this.index2Weight );
		return true;
	}
	
	public synchronized final Reference2DoubleMap<Index> getWeights() {
		return new Reference2DoubleOpenHashMap<Index>( index2Weight, Hash.VERY_FAST_LOAD_FACTOR );
	}
	
	
	/** Computes a score by calling {@link #score(Index)} for
	 * each index in the current index map, and summing the weighted results.
	 * 
	 * @return the combined weighted score.
	 */
	public double score() throws IOException {
		final double weight[] = this.currWeight;
		final Index index[] = this.currIndex;
		double result = 0;
		for( int i = n; i-- != 0; ) result += weight[ i ] * score( index[ i ] );
		return result;	
	}

	/** Wraps the given document iterator.
	 * 
	 * <p>Besides the services provided by {@link AbstractIndexScorer#wrap(DocumentIterator)},
	 * this method sets up {@link #currWeight}.
	 * 
	 * @param documentIterator the document iterator that will be used in subsequent calls to
	 * {@link #score()} and {@link #score(Index)}. 
	 */
	
	public void wrap( final DocumentIterator documentIterator ) throws IOException {
		super.wrap( documentIterator );
		this.documentIterator = documentIterator;
		currWeight = new double[ n ];
		for( int i = n; i-- != 0; ) currWeight[ i ] = index2Weight.getDouble( currIndex[ i ] );
	}
	
}
