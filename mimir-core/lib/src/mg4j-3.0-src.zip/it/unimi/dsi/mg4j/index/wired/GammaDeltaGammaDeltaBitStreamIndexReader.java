






package it.unimi.dsi.mg4j.index.wired;



/*		 
 * MG4J: Managing Gigabytes for Java
 *
 * Copyright (C) 2003-2006 Paolo Boldi and Sebastiano Vigna 
 *
 *  This library is free software; you can redistribute it and/or modify it
 *  under the terms of the GNU Lesser General Public License as published by the Free
 *  Software Foundation; either version 2.1 of the License, or (at your option)
 *  any later version.
 *
 *  This library is distributed in the hope that it will be useful, but
 *  WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 *  or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License
 *  for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 */

import it.unimi.dsi.fastutil.ints.IntIterator;
import it.unimi.dsi.fastutil.ints.IntIterators;
import it.unimi.dsi.fastutil.ints.IntSet;
import it.unimi.dsi.fastutil.objects.AbstractObjectIterator;
import it.unimi.dsi.fastutil.objects.Reference2ReferenceMap;
import it.unimi.dsi.fastutil.objects.Reference2ReferenceMaps;
import it.unimi.dsi.fastutil.objects.ReferenceSet;
import it.unimi.dsi.mg4j.index.AbstractIndexIterator;
import it.unimi.dsi.mg4j.index.AbstractIndexReader;
import it.unimi.dsi.mg4j.index.BitStreamIndex;
import it.unimi.dsi.mg4j.index.Index;
import it.unimi.dsi.mg4j.index.IndexIterator;
import it.unimi.dsi.mg4j.index.CompressionFlags.Coding;
import it.unimi.dsi.mg4j.index.payload.Payload;
import it.unimi.dsi.io.InputBitStream;
import it.unimi.dsi.util.Interval;
import it.unimi.dsi.mg4j.search.IntervalIterator;
import it.unimi.dsi.mg4j.search.IntervalIterators;
import it.unimi.dsi.Util;





import java.io.IOException;
import java.util.NoSuchElementException;

import org.apache.log4j.Logger;





public class GammaDeltaGammaDeltaBitStreamIndexReader extends AbstractIndexReader {
 @SuppressWarnings("unused")
 private static final Logger LOGGER = Util.getLogger( GammaDeltaGammaDeltaBitStreamIndexReader.class );

 /** The reference index. */
 protected final BitStreamIndex index;

 private final static boolean ASSERTS = false;
 private final static boolean DEBUG = false;

 /** The {@link IndexIterator} view of this reader (returned by {@link #documents(CharSequence)}). */
 protected final BitStreamIndexReaderIndexIterator indexIterator;

 /** Creates a new skip index reader, with the specified underlying {@link Index} and input bit stream.
	 *
	 * @param index the index.
	 * @param ibs the underlying bit stream.
	 */
 public GammaDeltaGammaDeltaBitStreamIndexReader( final BitStreamIndex index, final InputBitStream ibs ) {
  this.index = index;
  this.indexIterator = new BitStreamIndexReaderIndexIterator( this, ibs );
 }

 protected static final class BitStreamIndexReaderIndexIterator extends AbstractIndexIterator implements IndexIterator {
  /** The enclosing instance. */
  private final GammaDeltaGammaDeltaBitStreamIndexReader parent;
  /** The reference index. */
  protected final BitStreamIndex index;
  /** The underlying input bit stream. */
  protected final InputBitStream ibs;
  /** The enclosed interval iterator. */
  private final IndexIntervalIterator intervalIterator;
  /** A singleton set containing the enclosed interval iterator. */
  private final Reference2ReferenceMap<Index,IntervalIterator> singletonIntervalIterator;
  /** The key index. */
  private final Index keyIndex;
  /** The cached copy of {@link #index index.pointerCoding}. */
  protected final Coding pointerCoding;
  /** The cached copy of {@link #index index.countCoding}. */
  protected final Coding countCoding;
  /** The cached copy of {@link #index index.positionCoding}. */
  protected final Coding positionCoding;
  /** The current term. */
  protected int currentTerm = -1;
  /** The current frequency. */
  protected int frequency;
  /** Whether the current terms has pointers at all (this happens when the {@link #frequency} is smaller than the number of documents). */
  protected boolean hasPointers;
  /** The current count (if this index contains counts). */
  protected int count;
  /** The last document pointer we read from current list, -1 if we just read the frequency,
		 * {@link Integer#MAX_VALUE} if we are beyond the end of list. */
  protected int currentDocument;
  /** The number of the document record we are going to read inside the current inverted list. */
  protected int numberOfDocumentRecord;
  /** This variable tracks the current state of the reader. */
  protected int state;
  /** The initial size of {@link #positionCache}. */
  private static final int POSITION_CACHE_INITIAL_SIZE = 16;
  /** This value of {@link #state} can be assumed only in indices that contain a payload; it
		 * means that we are positioned just before the payload for the current document record. */
  @SuppressWarnings("unused")
  private static final int BEFORE_PAYLOAD = 1;
  /** This value of {@link #state} can be assumed only in indices that contain counts; it
		 * means that we are positioned just before the count for the current document record. */
  private static final int BEFORE_COUNT = 2;
  /** This value of {@link #state} can be assumed only in indices that contain document positions; 
		 * it means that we are positioned just before the position list of the current document record. */
  private static final int BEFORE_POSITIONS = 3;
  /** This value of {@link #state} means that we are at the start of a new document record, 
		 * unless we already read all documents (i.e., {@link #numberOfDocumentRecord} == {@link #frequency}),
		 * in which case we are at the end of the inverted list, and {@link #endOfList()} is true. */
  private static final int BEFORE_POINTER = 4;
  /** The cached position array. */
  protected int[] positionCache;
  public BitStreamIndexReaderIndexIterator( final GammaDeltaGammaDeltaBitStreamIndexReader parent, final InputBitStream ibs ) {
   this.parent = parent;
   this.ibs = ibs;
   index = parent.index;
   keyIndex = index.keyIndex;
   pointerCoding = index.pointerCoding;
   if ( index.hasPayloads ) throw new IllegalStateException();
   if ( ! index.hasCounts ) throw new IllegalStateException();
   countCoding = index.countCoding;
   if ( ! index.hasPositions ) throw new IllegalStateException();
   positionCoding = index.positionCoding;
   positionCache = new int[ POSITION_CACHE_INITIAL_SIZE ];
   intervalIterator = index.hasPositions ? new IndexIntervalIterator() : null;
   singletonIntervalIterator = index.hasPositions ? Reference2ReferenceMaps.singleton( keyIndex, (IntervalIterator)intervalIterator ) : null;
  }
  /** Positions the index on the inverted list of a given term.
		 *
		 * <p>This method can be called at any time. Note that it is <em>always</em> possible
		 * to call this method with argument 0, even if offsets have not been loaded.
		 *
		 * @param term a term.
		 */
  protected void position( final int term ) throws IOException {
   if ( term == 0 ) {
    ibs.position( 0 );
    ibs.readBits( 0 );
   }
   else {
    if ( index.offsets == null ) throw new IllegalStateException( "You cannot position an index without offsets" );
    final long offset = index.offsets.getLong( term );
    ibs.position( offset );
    // TODO: Can't we set this to 0?
    ibs.readBits( offset );
   }
   currentTerm = term;
   readFrequency();
  }
  public int termNumber() {
   return currentTerm;
  }
  protected IndexIterator advance() throws IOException {
   if ( currentTerm == index.numberOfTerms - 1 ) return null;
   if ( currentTerm != -1 ) {
    skipTo( Integer.MAX_VALUE );
    nextDocument(); // This guarantees we have no garbage before the frequency
   }
   currentTerm++;
   readFrequency();
   return this;
  }
  private void readFrequency() throws IOException {
   // Read the frequency
    frequency = ibs.readGamma() + 1;
   hasPointers = frequency < index.numberOfDocuments;
   count = -1;
   currentDocument = -1;
   numberOfDocumentRecord = -1;
   state = BEFORE_POINTER;
  }
  public Index index() {
   return keyIndex;
  }
  public int frequency() {
   return frequency;
  }
  private void ensureCurrentDocument() {
   if ( currentDocument < 0 ) throw new IllegalStateException( "nextDocument() has never been called for (term=" + currentTerm + ")" );
   if ( currentDocument == Integer.MAX_VALUE ) throw new IllegalStateException( "This reader is positioned beyond the end of list of (term=" + currentTerm + ")" );
  }
  /** Returns whether there are no more document records in the current inverted list.
		 * 
		 * <p>This method returns true if the last document pointer of the current inverted
		 * list has been read. It makes no distinction as to where (inside the last document
		 * record) this reader is currently positioned. In particular, this method will
		 * return true independently of whether count and positions have been read or not (we
		 * note by passing that this is the only sensible behaviour, as you can build indices
		 * with or without counts/positions).
		 * 
		 * <p>This method will return true also when this reader is positioned <em>beyond</em>
		 * the last document pointer. In this case, {@link #currentDocumentPointer()} will
		 * return {@link Integer#MAX_VALUE}.
		 *
		 * @return true whether there are no more document records in the current inverted list.
		 */
  private boolean endOfList() {
   if ( ASSERTS ) assert numberOfDocumentRecord <= frequency;
   return numberOfDocumentRecord >= frequency - 1;
  }
  public int document() {
   if ( ASSERTS ) ensureCurrentDocument();
   return currentDocument;
  }
  public Payload payload() throws IOException {
   if ( DEBUG ) System.err.println( this + ".payload()" );
   if ( ASSERTS ) ensureCurrentDocument();
    throw new UnsupportedOperationException( "This index ("+ index + ") does not contain payloads" );
  }
  public int count() throws IOException {
   if ( DEBUG ) System.err.println( this + ".count()" );
   if ( count != -1 ) return count;
   if ( ASSERTS ) ensureCurrentDocument();
  {
   state = BEFORE_POSITIONS;
    count = ibs.readGamma() + 1;
  }
   return count;
  }
  /** We read positions, assuming state <= BEFORE_POSITIONS */
  @SuppressWarnings("unused")
  protected void updatePositionCache() throws IOException {
   if ( ASSERTS ) assert state <= BEFORE_POSITIONS;
   if ( state < BEFORE_POSITIONS ) {
    if ( state == BEFORE_COUNT )
  {
   state = BEFORE_POSITIONS;
    count = ibs.readGamma() + 1;
  }
   }
    if ( count > positionCache.length ) positionCache = new int[ Math.max( positionCache.length * 2, count ) ];
    final int[] occ = positionCache;
    state = BEFORE_POINTER;
     ibs.readDeltas( occ, count );
     for( int i = 1; i < count; i++ ) occ[ i ] += occ[ i - 1 ] + 1;
  }
  public IntIterator positions() throws IOException {
   if ( ASSERTS ) ensureCurrentDocument();
   if ( state <= BEFORE_POSITIONS ) updatePositionCache();
   return IntIterators.wrap( positionCache, 0, count );
  }
  public int[] positionArray() throws IOException {
   if ( ASSERTS ) ensureCurrentDocument();
   if ( state <= BEFORE_POSITIONS ) updatePositionCache();
   return positionCache;
  }
  // TODO: check who's using this (positionArray() is actually faster now)
  public int positions( final int[] position ) throws IOException {
   if ( ASSERTS ) ensureCurrentDocument();
   if ( state <= BEFORE_POSITIONS ) updatePositionCache(); // And also that positions have been read
   if ( position.length < count ) return -count;
   for( int i = count; i-- != 0; ) position[ i ] = this.positionCache[ i ];
   return count;
  }
  public int nextDocument() throws IOException {
   if ( DEBUG ) System.err.println( "{" + this + "} nextDocument()" );
   if ( state != BEFORE_POINTER ) {
    if ( state == BEFORE_COUNT )
  {
   state = BEFORE_POSITIONS;
    count = ibs.readGamma() + 1;
  }
    if ( state == BEFORE_POSITIONS ) {
     // Here we just skip; note that the state change is necessary if endOfList() is true
     state = BEFORE_POINTER;
      ibs.skipDeltas( count );
    }
   }
   if ( endOfList() ) return -1;
   if ( hasPointers ) {// We do not write pointers for everywhere occurring terms.
     currentDocument += ibs.readDelta() + 1;
   }
   else currentDocument++;
   numberOfDocumentRecord++;
    state = BEFORE_COUNT;
   count = -1;
   return currentDocument;
  }
  public int skipTo( final int p ) throws IOException {
   if ( DEBUG ) System.err.println( this + ".skipTo(" + p + ") [currentDocument=" + currentDocument + ", numberOfDocumentRecord=" + numberOfDocumentRecord + ", endOfList()=" + endOfList() );
   // If we are just at the start of a list, let us read the first pointer.
   if ( numberOfDocumentRecord == -1 ) nextDocument(); // TODO: shouldn't we just read the tower?
   if ( currentDocument >= p ) {
    if ( DEBUG ) System.err.println( this + ": No skip necessary, returning " + currentDocument );
    return currentDocument;
   }
   while( currentDocument < p ) {
    if ( DEBUG ) System.err.println( this + ": Skipping sequentially (second), currentDocument=" + currentDocument + ", numberOfDocumentRecord=" + numberOfDocumentRecord + ", p=" + p );
    if ( nextDocument() == -1 ) {
     if ( DEBUG ) System.err.println( this + ": end-of-list, returning MAX_VALUE" );
     return Integer.MAX_VALUE;
    }
   }
   if ( DEBUG ) System.err.println( this + ".toSkip(): Returning " + currentDocument );
   return currentDocument;
  }
  public void dispose() throws IOException {
   parent.close();
  }
  public boolean hasNext() {
   return ! endOfList();
  }
  public int nextInt() {
   if ( ! hasNext() ) throw new NoSuchElementException();
   try {
    return nextDocument();
   }
   catch ( IOException e ) {
    throw new RuntimeException( e );
   }
  }
  public String toString() {
   return index + " [" + currentTerm + "]" + ( weight != 1 ? "{" + weight + "}" : "" );
  }
  /** An interval iterator returning the positions of the current document as singleton intervals. */
  private final class IndexIntervalIterator extends AbstractObjectIterator<Interval> implements IntervalIterator {
   int pos = -1;
   public void reset() throws IOException {
    pos = -1;
    if ( state <= BEFORE_POSITIONS ) updatePositionCache(); // This guarantees the position cache is ok 
   }
   public void intervalTerms( final IntSet terms ) {
    terms.add( BitStreamIndexReaderIndexIterator.this.currentTerm );
   }
   public boolean hasNext() {
    return pos < count - 1;
   }
   public Interval next() {
    if ( ! hasNext() ) throw new NoSuchElementException();
    return Interval.valueOf( positionCache[ ++pos ] );
   }
   public Interval nextInterval() {
    return pos < count - 1 ? Interval.valueOf( positionCache[ ++pos ] ) : null;
   }
   public int extent() {
    return 1;
   }
   public String toString() {
    return index + ": " + term + "[doc=" + currentDocument + ", count=" + count + ", pos=" + pos + "]";
   }
  };
  public Reference2ReferenceMap<Index,IntervalIterator> intervalIterators() throws IOException {
   intervalIterator();
   return singletonIntervalIterator;
  }
  public IntervalIterator intervalIterator() throws IOException {
   return intervalIterator( keyIndex );
  }
  public IntervalIterator intervalIterator( final Index index ) throws IOException {
   if ( ASSERTS ) ensureCurrentDocument();
   // TODO: this was if ( index != keyIndex || hasPayloads ) 
   if ( index != keyIndex ) return IntervalIterators.TRUE;
   if ( ASSERTS ) assert intervalIterator != null;
   intervalIterator.reset();
   return intervalIterator;
  }
  public ReferenceSet<Index> indices() {
   return index.singletonSet;
  }
 }
 private IndexIterator documents( final CharSequence term, final int termNumber ) throws IOException {
  indexIterator.term( term );
  indexIterator.position( termNumber );
  return indexIterator;
 }
 public IndexIterator documents( final int term ) throws IOException {
  return documents( null, term );
 }
 public IndexIterator documents( final CharSequence term ) throws IOException {
  if ( closed ) throw new IllegalStateException( "This " + getClass().getSimpleName() + " has been closed" );
  if ( index.termMap != null ) {
   final int termIndex = (int)index.termMap.getLong( term );
   if ( termIndex == -1 ) return index.getEmptyIndexIterator( term, termIndex );
   return documents( term, termIndex );
  }
  throw new UnsupportedOperationException( "Index " + index + " has no term map" );
 }
  @Override
  public IndexIterator nextIterator() throws IOException {
   return indexIterator.advance();
  }
 public String toString() {
  return getClass().getSimpleName() + "[" + index + "]";
 }
 public void close() throws IOException {
  super.close();
  indexIterator.ibs.close();
 }
}
